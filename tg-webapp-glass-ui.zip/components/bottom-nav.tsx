"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

export default function BottomNav() {
  const pathname = usePathname()
  const tabs = [
    { href: "/", label: "Home" },
    { href: "/tasks", label: "Tasks" },
    { href: "/withdraw", label: "Withdraw" },
  ]
  return (
    <nav className="fixed inset-x-4 bottom-4 z-40">
      <div className="mx-auto flex items-center justify-between gap-2 rounded-2xl border border-white/20 bg-white/15 backdrop-blur-md p-2 shadow-xl text-white">
        {tabs.map((t) => {
          const active = pathname === t.href
          return (
            <Link
              key={t.href}
              href={t.href}
              className={`flex-1 text-center rounded-xl px-4 py-2 text-sm ${active ? "bg-white/25" : "hover:bg-white/20"}`}
              aria-current={active ? "page" : undefined}
            >
              {t.label}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
