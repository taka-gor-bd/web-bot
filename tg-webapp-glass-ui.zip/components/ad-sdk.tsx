"use client"

import Script from "next/script"

declare global {
  interface Window {
    // Defined by libtl SDK with data-sdk="show_9696042"
    show_9696042?: (format: string) => Promise<unknown>
  }
}

export function AdSdkLoader({ onReady }: { onReady?: () => void }) {
  return (
    <Script
      src="https://libtl.com/sdk.js"
      strategy="afterInteractive"
      data-zone="9696042"
      data-sdk="show_9696042"
      onLoad={onReady}
    />
  )
}
