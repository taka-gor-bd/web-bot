"use client"

import type React from "react"
import { createContext, useContext, useEffect, useMemo, useState } from "react"
import Script from "next/script"
import { useSearchParams } from "next/navigation"

type TelegramUser = {
  id: number
  first_name: string
  last_name?: string
  username?: string
  language_code?: string
  photo_url?: string
}

type TelegramContextType = {
  user: TelegramUser | null
  ready: boolean
  hasTelegram: boolean
}

const TelegramContext = createContext<TelegramContextType>({
  user: null,
  ready: false,
  hasTelegram: false,
})

export function useTelegram() {
  return useContext(TelegramContext)
}

function getMockUser(): TelegramUser {
  return {
    id: 123456789,
    first_name: "Mock",
    last_name: "User",
    username: "mockuser",
    language_code: "en",
    photo_url: "https://i.pravatar.cc/100?img=13",
  }
}

declare global {
  interface Window {
    Telegram?: any
  }
}

export function TelegramProvider({
  children,
  enableScript = true,
}: {
  children: React.ReactNode
  enableScript?: boolean
}) {
  const [user, setUser] = useState<TelegramUser | null>(null)
  const [ready, setReady] = useState(false)
  const [hasTelegram, setHasTelegram] = useState(false)
  const search = useSearchParams()
  const mock = search?.get("mock") === "1"

  const initTelegram = () => {
    try {
      const tg = window.Telegram?.WebApp
      if (tg) {
        setHasTelegram(true)
        tg.expand?.()
        const u = tg?.initDataUnsafe?.user
        if (u) {
          setUser({
            id: u.id,
            first_name: u.first_name,
            last_name: u.last_name,
            username: u.username,
            language_code: u.language_code,
            photo_url: u.photo_url,
          })
        }
      } else {
        setHasTelegram(false)
        if (mock) setUser(getMockUser())
      }
    } catch {
      // ignore
    } finally {
      setReady(true)
    }
  }

  useEffect(() => {
    if (typeof window !== "undefined") {
      if (window.Telegram?.WebApp) {
        initTelegram()
      } else if (!enableScript) {
        initTelegram()
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mock])

  const value = useMemo(() => ({ user, ready, hasTelegram }), [user, ready, hasTelegram])

  return (
    <TelegramContext.Provider value={value}>
      {enableScript ? (
        <Script src="https://telegram.org/js/telegram-web-app.js" strategy="afterInteractive" onLoad={initTelegram} />
      ) : null}
      {children}
    </TelegramContext.Provider>
  )
}
