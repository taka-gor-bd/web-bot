"use client"

import type React from "react"

export function GlassCard({
  className,
  children,
}: {
  className?: string
  children: React.ReactNode
}) {
  const cls = ["rounded-2xl border border-white/20 bg-white/15 backdrop-blur-md shadow-lg", className]
    .filter(Boolean)
    .join(" ")
  return <div className={cls}>{children}</div>
}
