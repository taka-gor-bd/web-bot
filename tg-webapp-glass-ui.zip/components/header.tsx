"use client"

import { GlassCard } from "./glass-card"
import { useTelegram } from "./telegram-provider"

export default function HeaderGlass({ title = "" }: { title?: string }) {
  const { user } = useTelegram()
  const name = user?.first_name ? `${user.first_name}${user.last_name ? " " + user.last_name : ""}` : "Guest"
  const initials = user?.first_name?.[0]?.toUpperCase() || "G"
  const photo = user?.photo_url || "/default-avatar.png"

  return (
    <GlassCard className="flex items-center justify-between p-4">
      <div className="flex items-center gap-3 min-w-0">
        <div className="h-10 w-10 shrink-0 rounded-full ring-2 ring-white/30 overflow-hidden bg-white/20 flex items-center justify-center text-sm font-semibold">
          {photo ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={photo || "/placeholder.svg"} alt="Profile photo" className="h-full w-full object-cover" />
          ) : (
            <span>{initials}</span>
          )}
        </div>
        <div className="min-w-0">
          <div className="font-semibold truncate">{name}</div>
          {title ? <div className="text-xs text-white/70 truncate">{title}</div> : null}
        </div>
      </div>
      <span
        aria-label="Verified"
        title="Verified"
        className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-[#1DA1F2]/20 text-[#1DA1F2] text-sm"
      >
        ✓
      </span>
    </GlassCard>
  )
}
