import { NextResponse } from "next/server"
import { memoryStore, verifyTelegramInitData } from "@/lib/server-utils"

export async function POST(req: Request) {
  const BOT_TOKEN = process.env.BOT_TOKEN
  if (!BOT_TOKEN) return NextResponse.json({ ok: false, error: "BOT_TOKEN not configured" }, { status: 500 })

  const body = await req.json().catch(() => null)
  const initData = body?.initData as string | undefined
  const ref = String(body?.ref || "")
  if (!initData || !ref) return NextResponse.json({ ok: false, error: "initData/ref missing" }, { status: 400 })

  const v = verifyTelegramInitData(initData, BOT_TOKEN)
  if (!v.ok || !v.user) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 })

  // Avoid self-ref
  if (String(v.user.id) === ref) {
    return NextResponse.json({ ok: false, error: "self referral not allowed" }, { status: 400 })
  }

  // Log referral (replace with DB unique constraint)
  memoryStore.referrals.push({ referrerId: ref, userId: v.user.id, ts: Date.now() })

  return NextResponse.json({ ok: true })
}
