import { NextResponse } from "next/server"
import { memoryStore, verifyTelegramInitData } from "@/lib/server-utils"
import { calculateUserAdRewardPts } from "@/lib/config"

export async function POST(req: Request) {
  const BOT_TOKEN = process.env.BOT_TOKEN
  if (!BOT_TOKEN) return NextResponse.json({ ok: false, error: "BOT_TOKEN not configured" }, { status: 500 })

  const body = await req.json().catch(() => null)
  const initData = body?.initData as string | undefined
  const adId = body?.adId as string | undefined
  if (!initData) return NextResponse.json({ ok: false, error: "initData missing" }, { status: 400 })

  const v = verifyTelegramInitData(initData, BOT_TOKEN)
  if (!v.ok || !v.user) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 })

  // Log completion (replace with DB write)
  memoryStore.ads.push({ userId: v.user.id, ts: Date.now(), adId })

  // Server suggests reward points; your client can compare/use this
  const suggestedRewardPts = calculateUserAdRewardPts()
  return NextResponse.json({ ok: true, suggestedRewardPts })
}
