import { NextResponse } from "next/server"
import { memoryStore, verifyTelegramInitData } from "@/lib/server-utils"

export async function POST(req: Request) {
  const BOT_TOKEN = process.env.BOT_TOKEN
  if (!BOT_TOKEN) return NextResponse.json({ ok: false, error: "BOT_TOKEN not configured" }, { status: 500 })

  const body = await req.json().catch(() => null)
  const { initData, country, method, account, amountPts } = body || {}
  if (!initData || !country || !method || !account || !amountPts) {
    return NextResponse.json({ ok: false, error: "missing fields" }, { status: 400 })
  }

  const v = verifyTelegramInitData(initData, BOT_TOKEN)
  if (!v.ok || !v.user) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 })

  // Log request (replace with DB and business checks)
  memoryStore.withdrawals.push({
    userId: v.user.id,
    country,
    method,
    account,
    points: Number(amountPts),
    ts: Date.now(),
  })

  return NextResponse.json({ ok: true, status: "queued" })
}
