import { NextResponse } from "next/server"
import { verifyTelegramInitData } from "@/lib/server-utils"

export async function POST(req: Request) {
  const BOT_TOKEN = process.env.BOT_TOKEN
  if (!BOT_TOKEN) {
    return NextResponse.json({ ok: false, error: "BOT_TOKEN not configured" }, { status: 500 })
  }
  const body = await req.json().catch(() => null)
  const initData = body?.initData as string | undefined
  if (!initData) return NextResponse.json({ ok: false, error: "initData missing" }, { status: 400 })

  const result = verifyTelegramInitData(initData, BOT_TOKEN)
  if (!result.ok) return NextResponse.json({ ok: false, error: result.error }, { status: 401 })

  return NextResponse.json({ ok: true, user: result.user })
}
