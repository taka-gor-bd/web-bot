"use client"

import { Poppins } from "next/font/google"
import HeaderGlass from "@/components/header"
import { TelegramProvider, useTelegram } from "@/components/telegram-provider"
import { GlassCard } from "@/components/glass-card"
import BottomNav from "@/components/bottom-nav"
import { usePoints } from "@/lib/use-points"
import { ONE_TIME_TASKS } from "@/lib/config"
import { useEffect, useMemo, useState } from "react"
import { Copy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Toaster } from "@/components/ui/toaster"

const poppins = Poppins({ subsets: ["latin"], weight: ["400", "600", "700"] })

export default function TasksPage() {
  return (
    <TelegramProvider>
      <main className={poppins.className}>
        <Background />
        <div className="relative mx-auto max-w-md min-h-screen px-4 pb-28 pt-4 text-white">
          <HeaderGlass title="Tasks & Referral" />
          <section className="mt-4 space-y-3">
            <ReferralCard />
            <DailyTaskCard />
            <OneTimeTasksList />
          </section>
        </div>
        <BottomNav />
        <Toaster />
      </main>
    </TelegramProvider>
  )
}

function Background() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10">
      <img src="/images/bg.png" alt="" className="h-full w-full object-cover" />
      <div className="absolute inset-0 bg-black/35 backdrop-blur-sm" />
    </div>
  )
}

// Referral card with copy UI
function ReferralCard() {
  const { user } = useTelegram()
  const { setReferredBy } = usePoints()
  const { toast } = useToast()
  const [origin, setOrigin] = useState("")

  useEffect(() => {
    try {
      const sp = new URLSearchParams(window.location.search)
      const ref = sp.get("ref")
      if (ref) setReferredBy(ref)
      setOrigin(window.location.origin)
    } catch {}
  }, [setReferredBy])

  const myCode = user?.id?.toString() || "your_id"
  const myLink = useMemo(() => {
    if (!origin) return ""
    return `${origin}/tasks?ref=${myCode}`
  }, [origin, myCode])

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text)
      toast({ title: "কপি হয়েছে", description: "রেফার লিংক কপি করা হয়েছে" })
    } catch {
      toast({ title: "কপি ব্যর্থ", description: "ম্যানুয়ালি সিলেক্ট করে কপি করুন" })
    }
  }

  return (
    <GlassCard className="p-4">
      <div className="font-semibold">Referral</div>
      <div className="mt-1 text-sm text-white/80">আপনার রেফার কোড</div>
      <div className="mt-2 flex items-center gap-2">
        <div className="flex-1 rounded-xl border border-white/25 bg-white/10 px-3 py-2 text-sm">{myCode}</div>
        <button
          onClick={() => copy(myCode)}
          className="rounded-xl border border-white/25 bg-white/15 px-3 py-2 text-white hover:bg-white/25"
          title="কপি"
        >
          <div className="flex items-center gap-1">
            <Copy className="h-4 w-4" />
            <span className="text-sm">Copy</span>
          </div>
        </button>
      </div>

      <div className="mt-3 text-sm text-white/80">রেফার লিংক</div>
      <div className="mt-2 flex items-center gap-2">
        <div className="flex-1 truncate rounded-xl border border-white/25 bg-white/10 px-3 py-2 text-xs">
          {myLink || "Generating..."}
        </div>
        <button
          onClick={() => myLink && copy(myLink)}
          className="rounded-xl border border-white/25 bg-white/15 px-3 py-2 text-white hover:bg-white/25"
          title="লিংক কপি"
        >
          <div className="flex items-center gap-1">
            <Copy className="h-4 w-4" />
            <span className="text-sm">Copy</span>
          </div>
        </button>
      </div>

      <div className="mt-2 text-xs text-white/60">
        নোট: আসল রেফার কাউন্ট/রিওয়ার্ড সার্ভার ছাড়া নির্ভুলভাবে সম্ভব নয়। পরে সার্ভার API যুক্ত করলে ট্র্যাকিং হবে।
      </div>
    </GlassCard>
  )
}

// Daily task card is inserted by usePoints, keep same behavior as before
function DailyTaskCard() {
  const { isDailyDoneToday, completeDailyTaskToday, dailyTaskConfig } = usePoints()
  const { toast } = useToast()
  const done = isDailyDoneToday(dailyTaskConfig.id)

  function onGo() {
    window.open(dailyTaskConfig.link, "_blank", "noopener,noreferrer")
  }
  function onVerify() {
    if (done) {
      toast({ title: "আজকের কাজ হয়ে গেছে", description: "আগামীকাল আবার করুন" })
      return
    }
    const ok = completeDailyTaskToday(dailyTaskConfig.id, dailyTaskConfig.rewardPts)
    toast({ title: ok ? "Completed" : "Already done", description: ok ? `+${dailyTaskConfig.rewardPts} pts` : "" })
  }

  return (
    <GlassCard className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="font-semibold">{dailyTaskConfig.title}</div>
          <div className="text-sm text-white/80">{dailyTaskConfig.desc}</div>
          <div className="mt-1 text-xs text-white/70">Reward: +{dailyTaskConfig.rewardPts} pts (per day)</div>
          {done ? <div className="mt-1 text-xs text-emerald-300">আজকে সম্পন্ন হয়েছে ✅</div> : null}
        </div>
        <div className="flex shrink-0 flex-col gap-2">
          <button onClick={onGo} className="rounded-full bg-[#1DA1F2] px-4 py-2 text-white">
            Open
          </button>
          <button
            onClick={onVerify}
            disabled={done}
            className="rounded-full bg-white/20 px-4 py-2 text-white disabled:opacity-60 hover:bg-white/25"
            title={done ? "Completed for today" : "Verify completion"}
          >
            Verify
          </button>
        </div>
      </div>
    </GlassCard>
  )
}

// One-time tasks list with toast feedback
function OneTimeTasksList() {
  const { isOneTimeDone, completeOneTimeTask } = usePoints()

  const visible = ONE_TIME_TASKS.filter((t) => !isOneTimeDone(t.id))

  if (visible.length === 0) {
    return (
      <GlassCard className="p-4">
        <div className="text-sm text-white/80">All one-time tasks are completed. 🎉</div>
      </GlassCard>
    )
  }

  return (
    <>
      {visible.map((task) => (
        <GlassCard key={task.id} className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="font-semibold">{task.title}</div>
              <div className="text-sm text-white/80">{task.desc}</div>
              <div className="mt-1 text-xs text-white/70">Reward: +{task.rewardPts} pts</div>
            </div>
            <OneTimeActions
              taskId={task.id}
              link={task.link}
              reward={task.rewardPts}
              completeOneTimeTask={completeOneTimeTask}
            />
          </div>
        </GlassCard>
      ))}
    </>
  )
}

function OneTimeActions({
  taskId,
  link,
  reward,
  completeOneTimeTask,
}: { taskId: string; link: string; reward: number; completeOneTimeTask: any }) {
  const [visited, setVisited] = useState(false)
  const { toast } = useToast()
  function onJoin() {
    window.open(link, "_blank", "noopener,noreferrer")
    setVisited(true)
  }
  function onVerify() {
    if (!visited) {
      toast({ title: "Open করুন", description: "প্রথমে Open করে কাজ সম্পন্ন করুন" })
      return
    }
    const ok = completeOneTimeTask(taskId, reward)
    toast({ title: ok ? "Verified" : "Already completed", description: ok ? `+${reward} pts` : "" })
  }
  return (
    <div className="flex shrink-0 flex-col gap-2">
      <button onClick={onJoin} className="rounded-full bg-[#1DA1F2] px-4 py-2 text-white">
        Open
      </button>
      <button onClick={onVerify} className="rounded-full bg-white/20 px-4 py-2 text-white hover:bg-white/25">
        Verify
      </button>
    </div>
  )
}
