"use client"

import type React from "react"
import { Poppins } from "next/font/google"
import HeaderGlass from "@/components/header"
import { TelegramProvider } from "@/components/telegram-provider"
import { GlassCard } from "@/components/glass-card"
import BottomNav from "@/components/bottom-nav"
import { usePoints } from "@/lib/use-points"
import { WITHDRAW_ELIGIBILITY_POINTS, POINTS_PER_USD } from "@/lib/config"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Toaster } from "@/components/ui/toaster"

const poppins = Poppins({ subsets: ["latin"], weight: ["400", "600", "700"] })

export default function WithdrawPage() {
  return (
    <TelegramProvider>
      <main className={poppins.className}>
        <Background />
        <div className="relative mx-auto max-w-md min-h-screen px-4 pb-28 pt-4 text-white">
          <HeaderGlass title="Withdraw your points" />
          <section className="mt-4">
            <WithdrawForm />
          </section>
        </div>
        <BottomNav />
        <Toaster />
      </main>
    </TelegramProvider>
  )
}

function Background() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10">
      <img src="/images/bg.png" alt="" className="h-full w-full object-cover" />
      <div className="absolute inset-0 bg-black/35 backdrop-blur-sm" />
    </div>
  )
}

function WithdrawForm() {
  const { points, dollars, deductPoints, eligibleForWithdrawGate, currentMinWithdrawPoints, markWithdrawDone } =
    usePoints()
  const [country, setCountry] = useState("")
  const [method, setMethod] = useState("")
  const [account, setAccount] = useState("")
  const [amountPts, setAmountPts] = useState("")
  const { toast } = useToast()

  const eligibleGate = eligibleForWithdrawGate()
  const minPts = currentMinWithdrawPoints()

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    const pts = Math.floor(Number.parseFloat(amountPts || "0"))
    if (!country || !method || !account || !pts || pts <= 0) {
      toast({ title: "Fill all fields", description: "Valid amount (points) দিন" })
      return
    }
    if (!eligibleGate || points < WITHDRAW_ELIGIBILITY_POINTS) {
      toast({ title: "Not eligible", description: `কমপক্ষে ${WITHDRAW_ELIGIBILITY_POINTS} pts দরকার` })
      return
    }
    if (pts < minPts) {
      toast({ title: "Minimum not met", description: `মিনিমাম ${minPts} pts` })
      return
    }
    if (pts > points) {
      toast({ title: "Insufficient points", description: "ব্যালেন্স কম" })
      return
    }
    deductPoints(pts)
    markWithdrawDone()
    const usd = (pts / POINTS_PER_USD).toFixed(2)
    toast({ title: "Withdrawal submitted", description: `${pts} pts (~$${usd}) via ${method}` })
    setAmountPts("")
  }

  return (
    <GlassCard className="p-5">
      <div className="mb-3 text-sm text-white/80">
        Balance: {points.toLocaleString()} pts (~${dollars.toFixed(2)}) • Eligibility:{" "}
        {eligibleGate ? "Yes" : `Need ${WITHDRAW_ELIGIBILITY_POINTS - points} pts`}
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="country" className="mb-1 block text-sm">
              Country
            </label>
            <select
              id="country"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white"
            >
              <option value="" hidden>
                Select country
              </option>
              <option value="BD">Bangladesh</option>
              <option value="IN">India</option>
              <option value="US">United States</option>
              <option value="PH">Philippines</option>
            </select>
          </div>

          <div>
            <label htmlFor="method" className="mb-1 block text-sm">
              Payment Method
            </label>
            <select
              id="method"
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white"
            >
              <option value="" hidden>
                Select method
              </option>
              <option value="USDT-TRC20">USDT (TRC20)</option>
              <option value="BKASH">bKash</option>
              <option value="NAGAD">Nagad</option>
              <option value="PAYPAL">PayPal</option>
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="account" className="mb-1 block text-sm">
            Account / Wallet
          </label>
          <input
            id="account"
            value={account}
            onChange={(e) => setAccount(e.target.value)}
            placeholder="Wallet address / phone / email"
            className="w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white placeholder:text-white/60"
          />
        </div>

        <div>
          <label htmlFor="amountPts" className="mb-1 block text-sm">
            Amount (Points)
          </label>
          <input
            id="amountPts"
            type="number"
            min={0}
            step={1}
            value={amountPts}
            onChange={(e) => setAmountPts(e.target.value)}
            placeholder={`${minPts} or more`}
            className="w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white placeholder:text-white/60"
          />
          <div className="mt-1 text-xs text-white/70">
            Min this time: {minPts} pts • Eligibility gate: {WITHDRAW_ELIGIBILITY_POINTS} pts
          </div>
        </div>

        <button
          type="submit"
          disabled={!eligibleGate}
          className="w-full rounded-full bg-[#1DA1F2] px-4 py-3 text-white disabled:opacity-60"
          title={!eligibleGate ? `Need ${WITHDRAW_ELIGIBILITY_POINTS - points} more points` : ""}
        >
          Submit Withdraw
        </button>
      </form>
    </GlassCard>
  )
}
