import crypto from "crypto"

export type TelegramUser = {
  id: number
  first_name: string
  last_name?: string
  username?: string
  language_code?: string
  photo_url?: string
}

export function verifyTelegramInitData(initData: string, botToken: string) {
  // initData is querystring from Telegram WebApp
  const params = new URLSearchParams(initData)
  const hash = params.get("hash")
  if (!hash) return { ok: false, error: "hash missing" }

  const dataCheckString = Array.from(params.entries())
    .filter(([k]) => k !== "hash")
    .sort(([a], [b]) => (a > b ? 1 : -1))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n")

  const secretKey = crypto.createHmac("sha256", "WebAppData").update(botToken).digest()
  const hmac = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex")

  const ok = hmac === hash
  if (!ok) return { ok: false, error: "invalid hash" }

  // Parse user JSON from params.get("user")
  let user: TelegramUser | undefined
  try {
    const userRaw = params.get("user")
    if (userRaw) user = JSON.parse(userRaw) as TelegramUser
  } catch (_e) {
    // ignore JSON error
  }

  return { ok: true, user }
}

// Simple in-memory logs (replace with DB in production)
export const memoryStore = {
  ads: [] as Array<{ userId: number; ts: number; adId?: string }>,
  referrals: [] as Array<{ referrerId: string; userId: number; ts: number }>,
  withdrawals: [] as Array<{
    userId: number
    points: number
    method: string
    account: string
    country: string
    ts: number
  }>,
}
