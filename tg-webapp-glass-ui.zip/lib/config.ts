// কনফিগ: কনভার্সন/শেয়ার/লিমিট/টাস্ক

// কনভার্সন (UI-তে টেক্সট হিসেবে দেখাবেন না)
export const POINTS_PER_USD = 1000

// আনুমানিক eCPM (USD/1000 completed views)
export const ESTIMATED_ECPM_USD = 3

// ইউজার শেয়ার (যেমন 0.7 = 70%)
export const USER_SHARE = 0.7

// সেফটি মার্জিন (ট্যাক্স/ফি কভার)
export const SAFETY_MARGIN = 0.15

// প্রতি অ্যাড রিওয়ার্ড সীমা
export const MIN_REWARD_PTS = 1
export const MAX_REWARD_PTS = 15

// অ্যাড লিমিট/কুলডাউন
export const DAILY_AD_LIMIT = 40
export const AD_COOLDOWN_SECONDS = 30

// Withdraw রুলস
export const WITHDRAW_ELIGIBILITY_POINTS = 300
export const FIRST_WITHDRAW_MIN_POINTS = 200
export const NEXT_WITHDRAW_MIN_POINTS = 400

// Daily Task সেটআপ (প্রতিদিন একবারই)
export const DAILY_TASK = {
  id: "daily_channel_update",
  title: "Daily Channel Update",
  desc: "আজকের আপডেট দেখুন",
  link: "https://t.me/All_Bkash", // আপনি বলেছিলেন প্রতিদিনের আপডেট
  rewardPts: 5,
}

// One-time tasks (একবার করে হাইড)
export const ONE_TIME_TASKS = [
  {
    id: "join_earning_with_nahid",
    title: "Join: Earning with Nahid",
    desc: "চ্যানেলে যোগ দিন",
    link: "https://t.me/Earning_with_Nahid",
    rewardPts: 50,
  },
  {
    id: "join_btc_crop",
    title: "Join: BTC Crop",
    desc: "ক্রিপ্টো আপডেট",
    link: "https://t.me/btc_crop",
    rewardPts: 50,
  },
]

// প্রতি সম্পূর্ণ অ্যাডে ইউজার কত পয়েন্ট পাবেন (অটো ক্যালক)
export function calculateUserAdRewardPts(): number {
  const totalPtsPerAd = ESTIMATED_ECPM_USD // 1000 pts = $1 ধরে approx eCPM pts/ad
  const userPts = totalPtsPerAd * USER_SHARE * (1 - SAFETY_MARGIN)
  const rounded = Math.round(userPts)
  return Math.max(MIN_REWARD_PTS, Math.min(MAX_REWARD_PTS, rounded))
}
