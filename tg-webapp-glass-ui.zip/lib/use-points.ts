"use client"

import { useEffect, useMemo, useState } from "react"
import {
  AD_COOLDOWN_SECONDS,
  DAILY_AD_LIMIT,
  FIRST_WITHDRAW_MIN_POINTS,
  NEXT_WITHDRAW_MIN_POINTS,
  POINTS_PER_USD,
  WITHDRAW_ELIGIBILITY_POINTS,
  calculateUserAdRewardPts,
  DAILY_TASK,
} from "./config"

type TaskState = { joined: boolean; verified: boolean; rewarded: boolean }
type TasksMap = Record<string, TaskState>

type Stored = {
  points: number
  adsWatched: number
  tasks: TasksMap
  // Daily ads
  adsToday: number
  adsTodayDate: string // YYYY-MM-DD
  lastAdStartedAt: number | null // cooldown anchor (শেষ হওয়ার পর সেট হবে)
  hasWithdrawnBefore: boolean
  // Daily task status: id -> lastCompletedDate
  dailyTaskDone: Record<string, string | undefined>
  // One-time task done: id -> boolean
  oneTimeTaskDone: Record<string, boolean | undefined>
  // Referral (লোকাল ডিভাইসে সেভ)
  referredBy?: string
}

const KEY = "app_points_v5"

function todayStr() {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

function readStore(): Stored {
  if (typeof window === "undefined")
    return {
      points: 0,
      adsWatched: 0,
      tasks: {},
      adsToday: 0,
      adsTodayDate: todayStr(),
      lastAdStartedAt: null,
      hasWithdrawnBefore: false,
      dailyTaskDone: {},
      oneTimeTaskDone: {},
      referredBy: undefined,
    }
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) {
      return {
        points: 0,
        adsWatched: 0,
        tasks: {},
        adsToday: 0,
        adsTodayDate: todayStr(),
        lastAdStartedAt: null,
        hasWithdrawnBefore: false,
        dailyTaskDone: {},
        oneTimeTaskDone: {},
        referredBy: undefined,
      }
    }
    const data = JSON.parse(raw) as Stored
    return {
      points: data.points ?? 0,
      adsWatched: data.adsWatched ?? 0,
      tasks: data.tasks ?? {},
      adsToday: data.adsToday ?? 0,
      adsTodayDate: data.adsTodayDate ?? todayStr(),
      lastAdStartedAt: data.lastAdStartedAt ?? null,
      hasWithdrawnBefore: data.hasWithdrawnBefore ?? false,
      dailyTaskDone: data.dailyTaskDone ?? {},
      oneTimeTaskDone: data.oneTimeTaskDone ?? {},
      referredBy: data.referredBy,
    }
  } catch {
    return {
      points: 0,
      adsWatched: 0,
      tasks: {},
      adsToday: 0,
      adsTodayDate: todayStr(),
      lastAdStartedAt: null,
      hasWithdrawnBefore: false,
      dailyTaskDone: {},
      oneTimeTaskDone: {},
      referredBy: undefined,
    }
  }
}

function writeStore(s: Stored) {
  if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(s))
}

export function usePoints() {
  const [state, setState] = useState<Stored>(readStore())

  // ডেইলি রিসেট (রাত 12টার পর)
  useEffect(() => {
    const today = todayStr()
    setState((s) => (s.adsTodayDate !== today ? { ...s, adsToday: 0, adsTodayDate: today } : s))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => writeStore(state), [state])

  // UI dollars
  const dollars = useMemo(() => state.points / POINTS_PER_USD, [state.points])

  // Points helpers
  function addPoints(pts: number) {
    if (!pts || pts <= 0) return
    setState((s) => ({ ...s, points: s.points + pts }))
  }
  function deductPoints(pts: number) {
    if (!pts || pts <= 0) return
    setState((s) => ({ ...s, points: Math.max(0, s.points - pts) }))
  }

  // Ads: limit + cooldown
  function canStartAd() {
    const today = todayStr()
    if (state.adsTodayDate !== today) {
      // auto reset in-memory
      setState((s) => ({ ...s, adsToday: 0, adsTodayDate: today }))
    }
    const now = Date.now()
    const cooldownLeft = state.lastAdStartedAt
      ? Math.max(0, AD_COOLDOWN_SECONDS - Math.floor((now - state.lastAdStartedAt) / 1000))
      : 0
    const remaining = Math.max(0, DAILY_AD_LIMIT - state.adsToday)
    const ok = remaining > 0 && cooldownLeft === 0
    let reason: string | undefined
    if (remaining <= 0) reason = "আজকের সীমা শেষ"
    else if (cooldownLeft > 0) reason = `অপেক্ষা করুন ${cooldownLeft}s`
    return { ok, reason, remaining, cooldownLeft }
  }

  function markAdStart() {
    // স্টার্টে টাইম সেট করলে ইউজার বারবার ক্লিক করতে পারবে না
    setState((s) => ({ ...s, lastAdStartedAt: Date.now() }))
  }

  function rewardAfterAdCompletion() {
    const rewardPts = calculateUserAdRewardPts()
    setState((s) => {
      const today = todayStr()
      const resetToday = s.adsTodayDate !== today ? 0 : s.adsToday
      return {
        ...s,
        points: s.points + rewardPts,
        adsWatched: s.adsWatched + 1,
        adsToday: Math.min(DAILY_AD_LIMIT, resetToday + 1),
        adsTodayDate: today,
        lastAdStartedAt: Date.now(), // কুলডাউন শুরু (শেষ হওয়ার পর)
      }
    })
    return rewardPts
  }

  // Cooldown left (UI কাউন্টডাউন)
  function cooldownLeftSeconds() {
    const now = Date.now()
    if (!state.lastAdStartedAt) return 0
    const left = AD_COOLDOWN_SECONDS - Math.floor((now - state.lastAdStartedAt) / 1000)
    return Math.max(0, left)
  }

  // One-time tasks
  function isOneTimeDone(id: string) {
    return !!state.oneTimeTaskDone[id]
  }
  function completeOneTimeTask(id: string, rewardPts: number) {
    if (isOneTimeDone(id)) return false
    setState((s) => ({
      ...s,
      oneTimeTaskDone: { ...s.oneTimeTaskDone, [id]: true },
      points: s.points + rewardPts,
    }))
    return true
  }

  // Daily task
  function isDailyDoneToday(id: string) {
    const last = state.dailyTaskDone[id]
    return last === todayStr()
  }
  function completeDailyTaskToday(id: string, rewardPts: number) {
    if (isDailyDoneToday(id)) return false
    setState((s) => ({
      ...s,
      dailyTaskDone: { ...s.dailyTaskDone, [id]: todayStr() },
      points: s.points + rewardPts,
    }))
    return true
  }

  // Referral
  function setReferredBy(uplineId: string) {
    if (!uplineId) return
    setState((s) => (s.referredBy ? s : { ...s, referredBy: uplineId }))
  }

  // Withdraw rules
  function eligibleForWithdrawGate() {
    return state.points >= WITHDRAW_ELIGIBILITY_POINTS
  }
  function currentMinWithdrawPoints() {
    return state.hasWithdrawnBefore ? NEXT_WITHDRAW_MIN_POINTS : FIRST_WITHDRAW_MIN_POINTS
  }
  function markWithdrawDone() {
    setState((s) => ({ ...s, hasWithdrawnBefore: true }))
  }

  return {
    // balance
    points: state.points,
    dollars,
    // ads
    adsWatched: state.adsWatched,
    adsToday: state.adsToday,
    dailyLimit: DAILY_AD_LIMIT,
    cooldownSeconds: AD_COOLDOWN_SECONDS,
    canStartAd,
    markAdStart,
    rewardAfterAdCompletion,
    cooldownLeftSeconds,
    // one-time tasks
    isOneTimeDone,
    completeOneTimeTask,
    // daily task
    isDailyDoneToday,
    completeDailyTaskToday,
    dailyTaskConfig: DAILY_TASK,
    // referral
    referredBy: state.referredBy,
    setReferredBy,
    // withdraw
    eligibleForWithdrawGate,
    currentMinWithdrawPoints,
    markWithdrawDone,
  }
}
